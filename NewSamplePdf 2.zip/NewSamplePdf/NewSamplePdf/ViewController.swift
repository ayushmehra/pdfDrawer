//
//  ViewController.swift
//  samplePdf
//
//  Created by Ayush Mehra on 04/05/20.
//  Copyright © 2020 Ayush Mehra. All rights reserved.
//

import UIKit
import SimplePDF
import WebKit
class ViewController: UIViewController , WKUIDelegate, WKNavigationDelegate {
    
    @IBOutlet weak var webView: WKWebView!
    @IBOutlet weak var viewObj: UIView!
    @IBOutlet weak var constraint_WebViewHeight: NSLayoutConstraint!
     @IBOutlet weak var constraint_WebViewWidth: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialiseView()
        // Do any additional setup after loading the view.
    }
    
    func initialiseView()
    {
        self.webView.navigationDelegate = self
        let a4PaperSize = CGSize(width: 1700, height: 3000)
        let pdf = SimplePDF(pageSize: a4PaperSize)
        
        pdf.setContentAlignment(.right)
        
        // add logo image
        let logoImage = UIImage(named:"simple_pdf_logo")!
        pdf.addImage(logoImage)
        
        pdf.setContentAlignment(.center)
        pdf.addLineSpace(30)
        pdf.addText("ACCOUNT STATEMENT")
        pdf.addLineSpace(10)
        pdf.setContentAlignment(.left)
        
        pdf.setContentAlignment(.left)
        // pdf.addLineSpace(30)
        let main_string = "Fields specific to the payment gateway *"
        let string_to_color = "Fields specific to the payment gateway *"
        
        let range = (main_string as NSString).range(of: string_to_color)
        var attributedString = NSMutableAttributedString(string:main_string)
        attributedString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.red , range: range)
        
        let dataArray = [["Disclaimer: \n - This statement only provides details regarding various payment transactions carried out for the above number mentioned above.\n - The document neither reflects a title nor is to be used as a proof of ownership of any property or premise ", "Test1313132"]]
        let dataArray1 = [" CA No : Test1313132\n \n Meter No: 123\n \n Name: \n \n Address: 12/4/20\n \n Date of Meter Installation: failed\n  \n Date of statement generation: \n \n Time of statement generation:" ]
        let dataArray3 = [[" Bill Date", " Cycle"," Unit"," Bill Month"," Tariff"," Load"," Units\n consumed"," Current Month \nBill Amount"," Adjustments \n(Debit / Credit)"," Net Previous\n Balance"," Total Bill\n Amount"," Payment\n amount"," Payment\n Date"]]
        
        let dataArray2 = [["", "", "","", "", "","", "", "","", "", "",""]]
        
        pdf.addTable(1, columnCount: 1, rowHeight: 250.0, columnWidth: 1500.0, tableLineWidth: 2.0, font: UIFont.systemFont(ofSize: 16.0), dataArray: [dataArray1])
        
        pdf.addLineSpace(30)
         pdf.setContentAlignment(.center)
        pdf.addTable(1, columnCount: 13, rowHeight: 100.0, columnWidth: 115.0, tableLineWidth: 2.0, font: UIFont.systemFont(ofSize: 16.0), dataArray: dataArray3)

        pdf.addTable(1, columnCount: 13, rowHeight: 60.0, columnWidth: 115.0, tableLineWidth: 2.0, font: UIFont.systemFont(ofSize: 16.0), dataArray: dataArray2)
        pdf.addTable(1, columnCount: 13, rowHeight: 60.0, columnWidth: 115.0, tableLineWidth: 2.0, font: UIFont.systemFont(ofSize: 16.0), dataArray: dataArray2)
        pdf.addTable(1, columnCount: 13, rowHeight: 60.0, columnWidth: 115.0, tableLineWidth: 2.0, font: UIFont.systemFont(ofSize: 16.0), dataArray: dataArray2)
        pdf.addTable(1, columnCount: 13, rowHeight: 60.0, columnWidth: 115.0, tableLineWidth: 2.0, font: UIFont.systemFont(ofSize: 16.0), dataArray: dataArray2)
        pdf.addTable(1, columnCount: 13, rowHeight: 60.0, columnWidth: 115.0, tableLineWidth: 2.0, font: UIFont.systemFont(ofSize: 16.0), dataArray: dataArray2)
        pdf.addTable(1, columnCount: 13, rowHeight: 60.0, columnWidth: 115.0, tableLineWidth: 2.0, font: UIFont.systemFont(ofSize: 16.0), dataArray: dataArray2)
        pdf.addTable(1, columnCount: 13, rowHeight: 60.0, columnWidth: 115.0, tableLineWidth: 2.0, font: UIFont.systemFont(ofSize: 16.0), dataArray: dataArray2)
        pdf.addLineSpace(30)
         pdf.setContentAlignment(.left)
        pdf.addTable(1, columnCount: 1, rowHeight: 150.0, columnWidth: 1500.0, tableLineWidth: 2.0, font: UIFont.systemFont(ofSize: 16.0), dataArray: dataArray)
        
        
        pdf.addLineSpace(20.0)
        pdf.setContentAlignment(.left)
        //
        pdf.addLineSpace(20.0)
        pdf.addText("*Note:\n - There are 3 payment gateways that need to be configured on the mobile app - Billdesk, Paytm and Ingenico - There a certain fields which are specific to the payment gateways, which need to be included in the payment aknowledgement")
        
        //    let point = CGPoint(x: 0, y: 0)
        //    let point1 = CGPoint(x: 20, y: 20)
        //    pdf.drawLineFromPoint(point, to: point, lineWidth: 5)
        // Generate PDF data and save to a local file.
        if let documentDirectories = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first {
            
            let fileName = "example.pdf"
            let documentsFileName = documentDirectories + "/" + fileName
            
            let pdfData = pdf.generatePDFdata()
            
            do{
                try pdfData.write(to: URL(fileURLWithPath: documentsFileName), options: .atomic)
                
                print("\nThe generated pdf can be found at:")
                print("\n\t\(documentsFileName)\n")
            }catch{
                print(error)
            }
            let pdf =  URL(fileURLWithPath: documentsFileName)
            let preference = WKPreferences()
            preference.javaScriptEnabled = true
            let configuration = WKWebViewConfiguration()
            configuration.preferences = preference
            webView = WKWebView(frame: view.bounds, configuration: configuration)
            view.addSubview(webView)
            
            webView.uiDelegate = self
            webView.navigationDelegate = self
            webView.load(URLRequest(url: pdf))
            webView.scrollView.showsHorizontalScrollIndicator = true
            webView.scrollView.contentSize.width = 900.0
            //
            //              let req = NSURLRequest(url: pdf)
            //              webView.loadRequest(req as URLRequest)
            
        }
        
    }
    
    
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        //            activityIndicator.isHidden = false
        //            activityIndicator.startAnimating()
        
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.constraint_WebViewHeight.constant = webView.scrollView.contentSize.height
         //   self.constraint_WebViewWidth.constant = webView.scrollView.contentSize.width
        }
        
    }
    
    
}



